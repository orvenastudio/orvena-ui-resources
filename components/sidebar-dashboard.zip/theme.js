// ===== ORVENA STUDIO — SHARED THEME SYSTEM =====
// Include this script at the bottom of every template page.
// It injects the toggle button and handles persistence via localStorage.

(function () {
  const STORAGE_KEY = 'orvena-theme';

  // Inject the toggle button into the page
  function injectToggleButton() {
    const btn = document.createElement('button');
    btn.id = 'themeToggleBtn';
    btn.className = 'theme-toggle-btn';
    btn.setAttribute('aria-label', 'Toggle dark/light mode');
    btn.setAttribute('title', 'Toggle dark/light mode');
    document.body.appendChild(btn);
    return btn;
  }

  // Apply a theme
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    const btn = document.getElementById('themeToggleBtn');
    if (btn) btn.textContent = theme === 'light' ? '🌙' : '☀️';
    localStorage.setItem(STORAGE_KEY, theme);
  }

  // Get saved or system preference
  function getInitialTheme() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return saved;
    // Respect OS preference by default (most users expect dark default for dev tools)
    return 'dark';
  }

  // Wait for DOM
  document.addEventListener('DOMContentLoaded', function () {
    const btn = injectToggleButton();
    const initial = getInitialTheme();
    applyTheme(initial);

    btn.addEventListener('click', function () {
      const current = document.documentElement.getAttribute('data-theme') || 'dark';
      applyTheme(current === 'dark' ? 'light' : 'dark');
    });
  });
})();
